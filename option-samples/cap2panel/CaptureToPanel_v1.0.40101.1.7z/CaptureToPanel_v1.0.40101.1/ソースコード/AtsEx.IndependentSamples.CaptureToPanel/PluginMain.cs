﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AtsEx.PluginHost.Plugins;

using Zbx1425.DXDynamicTexture;

namespace AtsEx.IndependentSamples.CaptureToPanel
{
    [PluginType(PluginType.VehiclePlugin)]
    public class PluginMain : AssemblyPluginBase
    {
        private static readonly string TextureFileName = "cap2panel.png";
        private static readonly Size TextureSize = new Size(1024, 1024);
        private static readonly string TargetProcessName = "chrome";

        private readonly TextureHandle TextureHandle;

        private OtherProcessWindowCapturer Capturer = null;

        public PluginMain(PluginBuilder builder) : base(builder)
        {
            TextureHandle = TextureManager.Register(TextureFileName, TextureSize.Width, TextureSize.Height);
        }

        public override void Dispose()
        {
            TextureHandle.Dispose();
            Capturer?.Dispose();
        }

        public override TickResult Tick(TimeSpan elapsed)
        {
            if (Capturer is null)
            {
                ResetCapturer();
            }
            else
            {
                if (TextureHandle.IsCreated && TextureHandle.HasEnoughTimePassed(10))
                {
                    using (GDIHelper gdi = new GDIHelper(TextureHandle.Width, TextureHandle.Height))
                    {
                        Capturer.DrawCaptureTo(gdi.Graphics);
                        TextureHandle.Update(gdi);
                    }
                }
            }

            return new VehiclePluginTickResult();
        }

        private void ResetCapturer()
        {
            Capturer?.Dispose();
            if (OtherProcessWindowCapturer.TryCreate(TargetProcessName, BveHacker.MainFormSource, out Capturer))
            {
                Capturer.Lost += (sender, e) => ResetCapturer();
            }
        }
    }
}
