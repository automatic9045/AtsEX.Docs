﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Vanara.PInvoke;

namespace AtsEx.IndependentSamples.CaptureToPanel
{
    internal class OtherProcessWindowCapturer : IDisposable
    {
        private readonly Process Process;

        private readonly HWND HWnd;
        private readonly HDC DC;

        public bool IsLost { get; private set; } = false;

        public EventHandler Lost;

        private OtherProcessWindowCapturer(Process process, ISynchronizeInvoke synchronizingObject)
        {
            Process = process;
            HWnd = Process.MainWindowHandle;
            DC = WinFunctions.GetDC(HWnd.DangerousGetHandle());

            Process.EnableRaisingEvents = true;
            Process.SynchronizingObject = synchronizingObject;
            Process.Exited += (sender, e) =>
            {
                IsLost = true;
                Lost?.Invoke(this, EventArgs.Empty);
            };
        }

        public static OtherProcessWindowCapturer Create(string processName, ISynchronizeInvoke synchronizingObject)
        {
            (OtherProcessWindowCapturer created, int count) = TryCreate(processName, synchronizingObject);
            switch (count)
            {
                case 0:
                    throw new ArgumentException("指定した名前のプロセスで、ウィンドウを有するものが存在しません。");
                case 1:
                    return created;
                default:
                    throw new ArgumentException("指定した名前のプロセスで、ウィンドウを有するものが 2 つ以上存在します。");
            }
        }

        public static bool TryCreate(string processName, ISynchronizeInvoke synchronizingObject, out OtherProcessWindowCapturer result)
        {
            (OtherProcessWindowCapturer created, _) = TryCreate(processName, synchronizingObject);
            result = created;
            return !(result is null);
        }

        private static (OtherProcessWindowCapturer Created, int Count) TryCreate(string processName, ISynchronizeInvoke synchronizingObject)
        {
            Process[] processes = Process.GetProcessesByName(processName);

            OtherProcessWindowCapturer created = null;
            foreach (Process process in processes)
            {
                if (process.MainWindowHandle != IntPtr.Zero && process.MainWindowTitle != string.Empty)
                {
                    created = new OtherProcessWindowCapturer(process, synchronizingObject);
                    break;
                }
            }

            return (Created: created, Count: processes.Length);
        }

        public void Dispose()
        {
            User32.ReleaseDC(HWnd, DC);
        }

        public void DrawCaptureTo(Graphics graphics)
        {
            User32.GetClientRect(HWnd, out RECT clientRect);
            HDC hDC = new HDC(graphics.GetHdc());
            Gdi32.BitBlt(hDC, 0, 0,
                clientRect.Right - clientRect.Left, clientRect.Bottom - clientRect.Top,
                DC, 0, 0, Gdi32.RasterOperationMode.SRCCOPY);
            graphics.ReleaseHdc();
        }
    }
}
