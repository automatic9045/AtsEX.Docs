# AtsEX 外部アプリ画面キャプチャサンプル

外部アプリの画面キャプチャを取得し、リアルタイムに運転台パネルへ描画するサンプルです。

## 動作に必要なもの

- AtsEX ver1.0-RC5 (v1.0.40101.1) 以降
- 標準の AtsEX サンプルシナリオ

## ライセンス

[The MIT License](LICENSE)

## 使用ライブラリ等（アルファベット順）

#### [AtsEX](https://github.com/automatic9045/AtsEX) (MIT)

Copyright (c) 2022 automatic9045

#### AtsEX が参照するライブラリ

AtsEX の README をご参照ください。

#### [System.Buffers](https://github.com/dotnet/corefx) (MIT)

Copyright (c) .NET Foundation and Contributors

#### [System.Memory](https://github.com/dotnet/corefx) (MIT)

Copyright (c) .NET Foundation and Contributors

#### [System.Numerics.Vectors](https://github.com/dotnet/corefx) (MIT)

Copyright (c) .NET Foundation and Contributors

#### [System.Runtime.CompilerServices.Unsafe](https://github.com/dotnet/runtime) (MIT)

Copyright (c) .NET Foundation and Contributors

#### [Vanara.Core](https://github.com/dahall/vanara) (MIT)

Copyright (c) 2017 David Hall

#### [Vanara.PInvoke.Gdi32](https://github.com/dahall/vanara) (MIT)

Copyright (c) 2017 David Hall

#### [Vanara.PInvoke.Kernel32](https://github.com/dahall/vanara) (MIT)

Copyright (c) 2017 David Hall

#### [Vanara.PInvoke.Shared](https://github.com/dahall/vanara) (MIT)

Copyright (c) 2017 David Hall

#### [Vanara.PInvoke.User32](https://github.com/dahall/vanara) (MIT)

Copyright (c) 2017 David Hall